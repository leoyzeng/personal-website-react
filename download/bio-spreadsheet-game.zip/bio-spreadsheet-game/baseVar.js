var FOOD = "B"
var RESOURCE = "C"
var ENERGY = "D"
var BIOD = "E"
var WASTE = "F"
var sheet = SpreadsheetApp.openById("1XYxiIPp9yZHfcJ-Kk1URoqXETPI5FB8WHa7VfFLVNaA").getSheetByName("Sheet1")
var cell, value, cell1, value1, cell2, value2, cell3, value3
var numBuilding

var COAL = "J"
var FOSSIL = "K"
var SOLAR = "L"
var WIND = "M"
var HYDRO = "N"

// function updateSheet() {
//   sheet = SpreadsheetApp.openById("1XYxiIPp9yZHfcJ-Kk1URoqXETPI5FB8WHa7VfFLVNaA").getSheetByName("Sheet1")
// }