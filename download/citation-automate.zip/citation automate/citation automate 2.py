from selenium import webdriver
from selenium.webdriver.common.by import By


class TestCitation():

    def setup_method(self, method):
        self.driver = webdriver.Chrome()
        self.vars = {}

    def teardown_method(self, method):
        self.driver.quit()

    def repeat(self):
        self.driver.implicitly_wait(10)
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"website-button\"]").click()
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"citation-search-input\"]").click()
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"citation-search-input\"]").send_keys(link)
        self.driver.implicitly_wait(10)
        #self.driver.find_element(By.CSS_SELECTOR, ".sc-fzoXWK > .sc-fzoMdx").click()
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"cite-button\"]").click()
        self.driver.implicitly_wait(10)
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"submit-eval\"]").click()
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"form-next-button\"]").click()
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"create-new-cite-btn\"]").click()

    def start(self):
        self.driver.get("https://www.citationmachine.net/")
        self.driver.set_window_size(1294, 1407)
        self.driver.implicitly_wait(10)
        self.driver.find_element(By.CSS_SELECTOR, ".styled__CardContainer-sc-1468au2-0:nth-child(1) .sc-fzoMdx").click()
        self.driver.implicitly_wait(10)


file1 = open("list_of_webcites.txt","r")
f1 = file1.readlines()
citation = TestCitation()
citation.setup_method(citation)
citation.start()

for lineNum in f1:

    link = lineNum
    print(lineNum)

    citation.repeat()
